# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .modeling_qwen2_megatron import (
    ParallelQwen2ForCausalLM,
    # rmpad with megatron
    ParallelQwen2ForCausalLMRmPad,
    # rmpad with megatron and pipeline parallelism
    ParallelQwen2ForCausalLMRmPadPP,
    ParallelQwen2ForValueRmPad,
    ParallelQwen2ForValueRmPadPP,
    # original model with megatron
    ParallelQwen2Model,
)

__all__ = [
    "ParallelQwen2ForCausalLM",
    "ParallelQwen2ForCausalLMRmPad",
    "ParallelQwen2ForCausalLMRmPadPP",
    "ParallelQwen2ForValueRmPad",
    "ParallelQwen2ForValueRmPadPP",
    "ParallelQwen2Model",
]
